## demo 1

![](screenrecords/screen2.gif)


## demo 2

![](screenrecords/screen3.gif)


## demo 3

![](screenrecords/screen4.gif)